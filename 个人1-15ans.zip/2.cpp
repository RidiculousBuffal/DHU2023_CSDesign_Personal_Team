#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    vector<int>quick(n,0);
    for(int i=0;i<n;i++)
    {
        int tmp;
        cin>>tmp;
        quick[i]=tmp;
    }
    int i;
    cin>>i;
    for(int j=0;j<quick.size();j++)
    {
        cout<<quick[j]<<" ";
    }
    cout<<endl;
    cout<<endl;
    int k1=0,k2=quick.size()-1;
    while(k1<k2)
    {
        if(quick[k1]==i)
        {
            if(quick[k2]!=i) {
                swap(quick[k1], quick[k2]);
                k1++;
                k2--;
                continue;
            }
            else
            {
                k2--;
                continue;
            }
        }
        k1++;
    }
    for(int p=0;p<quick.size();p++)
    {
        if(quick[p]!=i)
        cout<<quick[p]<<" ";
        else
        {
            if(p==0)
            {
                cout<<"empty"<<endl;
            }
            return 0;
        }
    }
    return 0;
}