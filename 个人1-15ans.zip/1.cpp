#include <bits/stdc++.h>
using namespace std;
void solve_oj_2()
{
    int n;
    cin>>n;
    vector<int>quick(n,0);
    for(int i=0;i<n;i++)
    {
        int tmp;
        cin>>tmp;
        quick[i]=tmp;
    }
    int i;
    cin>>i;
    for(int j=0;j<quick.size();j++)
    {
        cout<<quick[j]<<" ";
    }
    cout<<endl;
    cout<<endl;
    int k1=0,k2=quick.size()-1;
    while(k1<k2)
    {
        if(quick[k1]==i)
        {
            if(quick[k2]!=i) {
                swap(quick[k1], quick[k2]);
                k1++;
                k2--;
                continue;
            }
            else
            {
                k2--;
                continue;
            }
        }
        k1++;
    }
    for(int p=0;p<quick.size();p++)
    {
        if(quick[p]!=i)
            cout<<quick[p]<<" ";
        else
        {
            if(p==0)
            {
                cout<<"empty"<<endl;
            }
          return;
        }
    }
}

void solve_oj_1()
{
    int n;
    cin>>n;
    vector<int>res(n,0);
    for(int i=0;i<n;i++)
    {
        int tmp;
        cin>>tmp;
        res[i]=tmp;
    }
    for(int i=0;i<n;i++)
    {
        if(i==0)
        {
            cout<<res[i];
        }
        else
        {
            cout<<" "<<res[i];
        }
    }
    cout<<endl;
    cout<<endl;
    int low=0,high=res.size()-1;
    while(low<high)
    {
        if(res[low]<0)
        {
            low++;
            continue;
        }
        else if(res[low]>0)
        {
            if(res[high]<0)
            {
                swap(res[low],res[high]);
                for(int i=0;i<n;i++)
                {
                    if(i==0)
                    {
                        cout<<res[i];
                    }
                    else
                    {
                        cout<<" "<<res[i];
                    }
                }
                cout<<endl;
                low++;
                high--;
                continue;
            }
            else
            {
                high--;
                continue;
            }
        }

    }
}
int main()
{
    solve_oj_1();
    return 0;
}